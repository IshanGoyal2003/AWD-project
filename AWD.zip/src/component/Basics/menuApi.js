const Menu = [
  {
    id: 1,
    image: "images/maggi.jpg",
    name: "maggi",
    category: "breakfast",
    price: "12₹",
    description:
    "Maggi   is an international brand of seasonings, instant soups, and noodles that originated in Switzerland in the late 19th century. The Maggi company was acquired by Nestlé in 1947.",
  },

  {
    id: 2,
    image: "images/allupakoda.jpg",
    name: "aloo pakoda",
    category: "evening",
    price: "20₹",
    description:"Aloo pakora recipe is a simple and easy snack which is a Punjabi style aloo pakora. Moist and soft on inside and crisp outside is aloo pakora, unlike other pakora’s"
  },
  {
    id: 3,
    image: "images/corn.jpg",
    name: "corn",
    category: "breakfast",
    price: "10₹",
    description:
      "Corn is a snack made by frying corn kernels and then flavoring with spice powders. There are a few different ways crispy corn is made in restaurants and fast food centers. . ",
  },
  {
    id: 4,
    image: "../images/chola.jpg",
    name: "Chana Masala",
    category: "lunch",
    price: "50₹",
    description:
"This Punjabi Chana Masala, also known as Chole Masala, is an authentic North Indian style curry made with white chickpeas, freshly powdered spices, onions, tomatoes and herbs. "

  },
  {
    id: 5,
    image: "../images/pizza.jpg",
    name: "pizza",
    category: "evening",
    price: "80₹",
    description:
"A dish made typically of flattened bread dough spread with a savory mixture usually including tomatoes and cheese and often other toppings and baked."    },
  {
    id: 6,
    image: "../images/nonvegthali.jpg",
    name: "Non-Veg Thali",
    category: "dinner",
    price: "180₹",
    description:
"Starting from the top, clockwise: this thali consists of chicken curry, aloo gobi, dal fry, roti, carrot halwa, boondi raita, and rice (placed in the centre)."
  },

  
  {
    id: 7,
    image: "../images/sweet.jpg",
    name: "gulab jamun",
    category: "Sweets",
    price: "60₹",
    description:
      "Gulab jamun is a sweet, originating in the Indian subcontinent and a type of mithai popular in India, Pakistan, Nepal, the Maldives , and Bangladesh, as well as Myanmar.   ",
  },
  {
    id: 8,
    image: "../images/rajmarice.jpg",
    name: "Rajma Rice",
    category: "lunch",
    price: "60₹",
    description:
"This popular dish is loved by people of all age groups. Rajma Chawal is perfect for a Sunday brunch or on a get-together. It is cooked by using easily available ingredients like rajma."

  },
  {
    id: 9,
    image: "../images/samosa.jpg",
    name: "samaso",
    category: "evening",
    price: "10₹",
    description:
"A samosa (/səˈmoʊsə/) is a fried or baked pastry with a savory filling, including ingredients such as spiced potatoes, onions, peas. It may take different forms, including triangular,"   },
  {
    id: 10,
    image: "../images/nonvegthali.jpg",
    name: "Veg Thali",
    category: "dinner",
    price: "150₹",
    description:
"The thali includes roti, rice, phakala (rice in fermented and spiced curd), dalma (signature lentil and vegetables dish), karela bhaja (bitter gourd fries), alu posto (potatoes with poppy seeds), baingan chatka (roasted brinjal mash), phulgobi kosha ."    },

  {
    id: 11,
    image: "../images/masaladosa.jpg",
    name: "Masala dosa",
    category: "breakfast",
    price: "150₹",
    description:
"In its most simple form, Dosa is very similar to a crepe and is a very popular street food in India. Dosa is famous for its simple ingredients, interesting flavors, and even its sweet aroma. I love it for how easy and clean the ingredients are."    },

  {
    id: 11,
    image: "../images/beetrootdosa.jpg",
    name: "Beetroot dosa",
    category: "breakfast",
    price: "150₹",
    description:
      "The beetroot is the taproot portion of a beet plant,[1] usually known in North America as beets while the vegetable is referred to as beetroot in British English, and also known as the table beet, garden beet, red beet, dinner beet or golden beet. ",
  },

  {
    id: 12,
    image: "../images/upma.jpg",
    name: "Upma",
    category: "breakfast",
    price: "150₹",
    description:
      " Upma is a dish originating from the Indian subcontinent, most common in Andhra Pradesh, Tamil Nadu, Telangana, Karnataka, Maharashtrian and Sri Lankan Tamil breakfast, cooked as a thick porridge from dry-roasted semolina or coarse rice flour ",
  },
  {
    id: 13,
    image: "../images/sproutsalad.jpg",
    name: "Sprouts salad",
    category: "breakfast",
    price: "150₹",
    description:
      "Soak the beans in water for about 8 hours then place in the colander. Wash twice a day. The sprouted beans can be eaten raw or cooked. Sprouting is also applied on a large scale to barley as a part of the malting process.  ",
  },


  {
    id: 14,
    image: "../images/parantha.jpg",
    name: "  Multigrain paranthas",
    category: "breakfast",
    price: "150₹",
    description:
    " Paratha  is a flatbread native to the Indian subcontinent,[1] prevalent throughout the modern-day nations of India, Sri Lanka, Pakistan, Nepal, Bangladesh, Maldives, Myanmar, Malaysia, Singapore, Mauritius, Fiji, Guyana, Suriname. ",
  },
  
  {
    id: 15,
    image: "../images/idli.jpg",
    name: "Idli sambhar",
    category: "breakfast",
    price: "150₹",
    description:
      "Idli  are a type of savoury rice cake, originating from the Indian subcontinent, popular as breakfast foods in Southern India and in Sri Lanka. The cakes are made by steaming a batter consisting of fermented black lentils (de-husked) and rice. . ",
  },

  {
    id: 16,
    image: "../images/dalia.jpg",
    name: "Dalia",
    category: "breakfast",
    price: "150₹",
    description:
    "Vegetable dalia is a great breakfast recipe with broken wheat cooked in water along with vegetables and seasonings. A fiber rich and energy giving vegetable dalia is quite simple to prepare  and also delicious when served hot with chopped coriander. ",
  },

  {
    id: 17,
    image: "../images/kadhaipaneer.jpg",
    name: "Shahi Paneer",
    category: "dinner",
    price: "150₹",
    description:
      "Shahi Paneer  is a slightly sweet creamy dish of paneer, originating from the Indian subcontinent, in which the gravy is prepared usually with butter ( makhan ), tomatoes, cashews or cream Spices such as red chili powder and garam masala . ",
  },

  {
    id: 18,
    image: "../images/misiroti.jpg",
    name: "Missi Roti",
    category: "dinner",
    price: "150₹",
    description:
      "Missi Roti is a North Indian flatbread prepared with chickpea flour, onions, ginger, kasuri methi and a few everyday spices. It is quite popular in Punjab and Rajasthan, especially on the road side dhabas. ",
  },

  {
    id: 19,
    image: "../images/chanamasala.jpg",
    name: "Chana Masala",
    category: "dinner",
    price: "150₹",
    description:
      "Chana masala literally 'mix-spiced small-chickpeas'), also known as channay, chole masala, chhole masala, chole or chholay (plural), is a dish originating from the Indian subcontinent.[1] The main ingredient is a variety of chickpea called chana  . ",
  },
  {
    id: 20,
    image: "../images/dalmakhani.jpg",
    name: "Dal makhani ",
    category: "dinner",
    price: "150₹",
    description:
      "Dal Makhani is a dish originating in New Delhi, India. It is a modern take on the age-old Urad ki Dal (black lentil dal also known as Maa ki Dal). Maa ki Dal has been a staple of North Indian cuisine for centuries. ",
  },
  {
    id: 21,
    image: "../images/butternaan.jpg",
    name: "Butter naan",
    category: "dinner",
    price: "150₹",
    description:
      "Naan is a natural marriage with Indian and Bangladeshi curries and gravies and can also be covered with, or served as a wrap for, various toppings of meat, vegetables, or cheeses. ",
  },
  
  {
    id: 22,
    image: "../images/stuffednan.jpg",
    name: "Stuff naan",
    category: "dinner",
    price: "150₹",
    description:
      "It consists of white flour, yeast, eggs, milk, salt, and sugar, baked in a tandoor oven. Its typical tear-drop shape is achieved by the way the dough droops as it cooks on the tandoor walls. ",
  },
  
  {
    id: 23,
    image: "../images/kadhichawal.jpg",
    name: "Kadhi chawal ",
    category: "lunch",
    price: "150₹",
    description:
      "  This Indian yogurt curry with rice is prepared by putting fried fritters in yogurt based curry. The deep fried pakodas submerged in thick creamy yogurt curry makes the experience unparallel.",
  },

  {
    id: 24,
    image: "../images/chickenchilly.jpg",
    name: "Chilly Chicken",
    category: "lunch",
    price: "150₹",
    description:
      "Chilli chicken is the most popular chinese style chicken preparation served as a starter or a side dish with chinese main course in any indo Chinese restaurant. ",
  },
  {
    id: 25,
    image: "../images/mttermuchroom.jpg",
    name: "Mutter Mushroom",
    category: "lunch",
    price: "150₹",
    description:
      "This mushroom mutter gravy is typical North Indian gravy. It is made from onion and tomato. it is spiced up with regular spices.Addition of kasoori methi gives the unique taste to it.  ",
  },
  {
    id: 26,
    image: "../images/masalabhindi.jpg",
    name: "Masala Bhindi",
    category: "lunch",
    price: "150₹",
    description:
      "Bhindi masala is stir-fried okra made with onion, tomato, and spices, a classic preparation for a side dish. Serve with warm rotis alongside dal tadka. ",
  },
  {
    id: 27,
    image: "../images/brownies.jpg",
    name: "Brownies",
    category: "Sweets",
    price: "150₹",
    description:
      "Decadently rich, fudgy and chewy - bake a batch and be your family's hero. These brownies are pure chocolate overload, perfect to bake on a lazy afternoon. ",
  },
  {
    id: 28,
    image: "../images/kheer.jpg",
    name: "Kheer",
    category: "Sweets",
    price: "150₹",
    description:
      "A delectable Indian dessert to prepare at home during special occasions and festivals, kesar (saffron) shrikhand has yogurt, cardamom and sugar mixed well with saffron milk. ",
  },
  {
    id: 29,
    image: "../images/kulfi.jpg",
    name: "Kulfi",
    category: "Sweets",
    price: "150₹",
    description:
      " This almond malai kulfi is like happiness condensed in a matki. To make it extra special, top it off with dry fruits and make sure it is absolutely chilled before serving. ",
  },
  {
    id: 30,
    image: "../images/applepie.jpg",
    name: "Apple pie",
    category: "Sweets",
    price: "150₹",
    description:
      "Just when you thought apple pie couldn't get any better, Top off this warm, melt-in-your mouth pie with a sprinkle of cinnamon and a scoop of ice cream. "
  },
  {
    id: 31,
    image: "../images/jalebi.jpg",
    name: "Jalebi",
    category: "Sweets",
    price: "150₹",
    description:
      "  It is made by deep-fryingmaida flour(plain flouror all-purpose flour) batterin pretzelor circular shapes, which are then soaked in sugar syrup ",
  },
  {
    id: 32,
    image: "../images/tandooriroti.jpg",
    name: "Tandoori roti",
    category: "lunch",
    price: "8₹",
    description:"According to Davidson (2014) the villages of Punjab had open-air tandoors where housewives would bring their dough to be rolled into rotis by the tandooriya.Steiner (2005) states that some villages in Punjab have communal tandoors"
         

  },

  {
    id: 33,
    image: "../images/plain.jpg",
    name: "Plain naan",
    category: "lunch",
    price: "15₹",
    description:"Naan bread is a type of bread made with flour. It is a flatbread that is baked in a tandoor. Naan bread often looks like a tear drop. It is often covered in herbs and spices such as garlic to change the taste. Naan Bread."
         

  },

  {
    id: 34,
    image: "../images/palakpaneer.jpg",
    name: "Palak paneer",
    category: "lunch",
    price: "180₹",
    description:"Palak paneer is prepared by first boiling and pureeing spinach.  Grilled cubes of paneer are then added to the puree. Palak paneer is typically spiced with ginger, garlic, tomatoes, garam masala, turmeric, chili powder and cumin"
         

  },
  {
    id: 35,
    image: "../images/dumaalo.jpg",
    name: "Dum Aloo",
    category: "dinner",
    price: "100₹",
    description:"Aloo Dum is a potato based curry dish. Aloo means potato and Dum means slow-cooked.[1] It is a part of the traditional Kashmiri Pandit cuisine, from the Kashmir Valley, in the Indian state of Jammu and Kashmir. "
         

  },

];

export default Menu;